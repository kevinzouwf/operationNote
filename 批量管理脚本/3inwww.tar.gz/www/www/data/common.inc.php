<?php
//数据库连接信息
$cfg_dbhost = '172.16.1.51';
$cfg_dbname = 'dedecms';
$cfg_dbuser = 'dedecms';
$cfg_dbpwd = '123456';
$cfg_dbprefix = 'dede_';
$cfg_db_language = 'utf8';


?>