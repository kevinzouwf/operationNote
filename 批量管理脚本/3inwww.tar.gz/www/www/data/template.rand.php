<?php

//这个值为 0 表示关闭此设置， 为 1 表示开启
$cfg_tamplate_rand = 0;

//模板数组，如果需要增加，按这个格式增加或修改即可(必须确保这些模板是存在的)，并且数量必须为2个或以上。
$cfg_tamplate_arr[] = 'article_article.htm';
$cfg_tamplate_arr[] = 'article_article1.htm';
$cfg_tamplate_arr[] = 'article_article2.htm';

?>
